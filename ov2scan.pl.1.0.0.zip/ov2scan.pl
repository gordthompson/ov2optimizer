#!/usr/bin/perl
if (!$ARGV[0]) {
	die "no file specified\n";
}
open FH, $ARGV[0] or die "error opening file: $!\n";
binmode FH;

$counts[0] = 0; $counts[1] = 0; $counts[2] = 0; $counts[3] = 0;

while (read(FH, $buf, 1)) {
	$recType = buildInteger($buf);
	if (($recType == 0) || ($recType == 2) || ($recType == 3)) {
		read(FH, $buf, 4);
		$restOfRecord = buildInteger($buf) - 5;
	}
	elsif ($recType == 1) {
		$restOfRecord = 20;
	}
	else {
		close FH;
		die "unrecognized OV2 record type $recType - file may be encrypted or corrupt\n";
	}
	$counts[$recType]++;
	read(FH, $buf, $restOfRecord);  # skip rest of record
}
close FH;

print " deleted POI records (type 0): $counts[0]\n";
print "     skipper records (type 1): $counts[1]\n";
print " regular POI records (type 2): $counts[2]\n";
print "extended POI records (type 3): $counts[3]\n";



sub buildInteger {
	$val = 0;
	for ($i = length($_[0]) - 1; $i >= 0; $i--) {
		$b = substr($_[0], $i, 1);
		$val = ($val * 256) + ord($b);
	}
	return $val;
}
